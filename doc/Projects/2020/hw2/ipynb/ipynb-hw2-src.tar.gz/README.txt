This IPython notebook hw2.ipynb does not require any additional
programs.
