This IPython notebook Project1.ipynb does not require any additional
programs.
